import React, { useState } from 'react';
import { Punch, Employee, PunchType, AbsenceRecord, EntryMethod, EntryModality, LocationConfig } from '../types';

interface HistoryViewProps {
  punches: Punch[];
  employees: Employee[];
  records: AbsenceRecord[];
  locationConfig: LocationConfig;
  onEditPunch: (punch: Punch) => void;
  onAddPunch: (punch: Punch) => void;
  onDeletePunch: (punchId: string) => void;
  onDeleteRecord: (recordId: string) => void;
  onEditRecord: (record: AbsenceRecord) => void;
  onIgnoreAbsence: (empId: string, date: string) => void;
  onDeleteAllPunches: () => void;
  onDeleteAllRecords: () => void;
}

const HistoryView: React.FC<HistoryViewProps> = ({ 
  punches, employees, records, 
  onEditPunch, onAddPunch, onDeletePunch, onDeleteRecord, onEditRecord,
  onDeleteAllPunches, onDeleteAllRecords
}) => {
  const [activeTab, setActiveTab] = useState<'PUNCHES' | 'OCCURRENCES'>('PUNCHES');
  const [searchTerm, setSearchTerm] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  
  // Modais de Lixeira
  const [punchToDelete, setPunchToDelete] = useState<string | null>(null);
  const [recordToDelete, setRecordToDelete] = useState<string | null>(null);
  const [showClearAllModal, setShowClearAllModal] = useState(false);

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isEditRecordModalOpen, setIsEditRecordModalOpen] = useState(false);
  
  const [editPunchData, setEditPunchData] = useState<Punch | null>(null);
  const [editRecordData, setEditRecordData] = useState<AbsenceRecord | null>(null);

  const handleAddSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const ts = new Date(`${fd.get('date')}T${fd.get('time')}:00`).toISOString();
    
    onAddPunch({
      id: Math.random().toString(36).substr(2, 9),
      employeeId: fd.get('employeeId') as string,
      type: fd.get('type') as PunchType,
      timestamp: ts,
      entryMethod: EntryMethod.MANUAL,
      modality: EntryModality.PIN,
      notes: fd.get('notes') as string
    });
    setIsAddModalOpen(false);
  };

  const handleEditSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editPunchData) return;
    const fd = new FormData(e.currentTarget);
    const ts = new Date(`${fd.get('date')}T${fd.get('time')}:00`).toISOString();

    onEditPunch({
      ...editPunchData,
      type: fd.get('type') as PunchType,
      timestamp: ts,
      entryMethod: fd.get('entryMethod') as EntryMethod,
      notes: fd.get('notes') as string
    });
    setIsEditModalOpen(false);
  };

  const handleEditRecordSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editRecordData) return;
    const fd = new FormData(e.currentTarget);
    
    onEditRecord({
      ...editRecordData,
      date: fd.get('date') as string,
      endDate: fd.get('endDate') as string || undefined,
      type: fd.get('type') as 'VACATION' | 'ABSENCE',
      reason: fd.get('reason') as string
    });
    setIsEditRecordModalOpen(false);
  };

  const getPunchEmployee = (p: Punch) => employees.find(e => e.id === p.employeeId);
  const getRecordEmployee = (r: AbsenceRecord) => employees.find(e => e.id === r.employeeId);

  const filterByRange = (dateStr: string) => {
    const d = dateStr.split('T')[0];
    if (startDate && d < startDate) return false;
    if (endDate && d > endDate) return false;
    return true;
  };

  const filteredPunches = punches.filter(p => {
    const matchesSearch = !searchTerm || getPunchEmployee(p)?.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch && filterByRange(p.timestamp);
  }).sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const filteredRecords = records.filter(r => {
    const matchesSearch = !searchTerm || getRecordEmployee(r)?.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch && filterByRange(r.date);
  }).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="space-y-6 animate-fade-in pb-20">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tight text-slate-900 dark:text-white italic">Gestão de Histórico</h2>
          <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Administração de Registos</p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => setShowClearAllModal(true)}
            title="Limpar Tudo"
            className="p-3 bg-rose-50 dark:bg-rose-900/20 text-rose-600 rounded-xl hover:bg-rose-600 hover:text-white transition-all shadow-sm"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
          </button>
          <button onClick={() => setIsAddModalOpen(true)} className="bg-indigo-600 text-white px-6 py-2.5 rounded-xl text-[10px] font-black uppercase shadow-lg hover:bg-indigo-500 transition-all">+ Novo Ponto</button>
        </div>
      </header>

      <div className="flex bg-slate-100 dark:bg-slate-900/50 p-1.5 rounded-2xl w-fit">
        <button onClick={() => setActiveTab('PUNCHES')} className={`px-6 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${activeTab === 'PUNCHES' ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-white shadow-sm' : 'text-slate-400'}`}>Pontos Registados</button>
        <button onClick={() => setActiveTab('OCCURRENCES')} className={`px-6 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${activeTab === 'OCCURRENCES' ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-white shadow-sm' : 'text-slate-400'}`}>Férias e Faltas</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-100 dark:border-white/5 shadow-sm">
        <input 
          type="text" 
          placeholder="Pesquisar Colaborador..." 
          value={searchTerm} 
          onChange={e => setSearchTerm(e.target.value)} 
          className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs font-bold dark:text-white outline-none"
        />
        <input 
          type="date" 
          value={startDate} 
          onChange={e => setStartDate(e.target.value)} 
          className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs font-bold dark:text-white outline-none"
        />
        <input 
          type="date" 
          value={endDate} 
          onChange={e => setEndDate(e.target.value)} 
          className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs font-bold dark:text-white outline-none"
        />
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-sm border border-slate-100 dark:border-white/5 overflow-hidden">
        {activeTab === 'PUNCHES' ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-400 text-[9px] font-black uppercase tracking-widest">
                <tr>
                  <th className="px-8 py-5">Data / Hora</th>
                  <th className="px-8 py-5">Colaborador</th>
                  <th className="px-8 py-5 text-center">Tipo (Método)</th>
                  <th className="px-8 py-5 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredPunches.map(p => {
                  const emp = getPunchEmployee(p);
                  return (
                    <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/20">
                      <td className="px-8 py-5 font-mono text-indigo-600 dark:text-indigo-400 font-black text-[10px]">{new Date(p.timestamp).toLocaleString('pt-PT')}</td>
                      <td className="px-8 py-5 font-black uppercase text-[10px] text-slate-700 dark:text-slate-200">{emp?.name || '---'}</td>
                      <td className="px-8 py-5 text-center">
                        <span className={`px-3 py-1.5 rounded-lg text-[8px] font-black uppercase ${p.type === PunchType.IN ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                          {p.type === PunchType.IN ? 'Entrada' : 'Saída'} 
                          <span className="opacity-50 ml-1 italic">({p.entryMethod === EntryMethod.MANUAL ? 'Manual' : 'Automática'})</span>
                        </span>
                      </td>
                      <td className="px-8 py-5 text-right">
                        <div className="flex justify-end gap-2">
                          <button onClick={() => { setEditPunchData(p); setIsEditModalOpen(true); }} className="p-2 hover:bg-indigo-50 rounded-lg text-indigo-600">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                          </button>
                          <button 
                            onClick={() => setPunchToDelete(p.id)} 
                            className="p-2 hover:bg-rose-50 rounded-lg text-rose-500"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-400 text-[9px] font-black uppercase tracking-widest">
                <tr>
                  <th className="px-8 py-5">Período</th>
                  <th className="px-8 py-5">Colaborador</th>
                  <th className="px-8 py-5 text-center">Tipo</th>
                  <th className="px-8 py-5">Motivo</th>
                  <th className="px-8 py-5 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredRecords.map(r => (
                  <tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/20">
                    <td className="px-8 py-5 text-[10px] font-mono font-black text-slate-700 dark:text-slate-300">
                      {new Date(r.date).toLocaleDateString('pt-PT')}
                      {r.endDate && ` a ${new Date(r.endDate).toLocaleDateString('pt-PT')}`}
                    </td>
                    <td className="px-8 py-5 font-black text-[10px] uppercase text-slate-700 dark:text-slate-200">{getRecordEmployee(r)?.name || '---'}</td>
                    <td className="px-8 py-5 text-center">
                      <span className={`px-2 py-1 rounded-lg text-[8px] font-black uppercase ${r.type === 'VACATION' ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'}`}>
                        {r.type === 'VACATION' ? 'Férias' : 'Falta'}
                      </span>
                    </td>
                    <td className="px-8 py-5 text-[10px] text-slate-400 italic line-clamp-1">{r.reason || 'Sem motivo'}</td>
                    <td className="px-8 py-5 text-right">
                      <div className="flex justify-end gap-2">
                        <button onClick={() => { setEditRecordData(r); setIsEditRecordModalOpen(true); }} className="p-2 hover:bg-indigo-50 rounded-lg text-indigo-600">
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                        </button>
                        <button 
                          onClick={() => setRecordToDelete(r.id)} 
                          className="p-2 hover:bg-rose-50 rounded-lg text-rose-500"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modais de Lixeira (Confirmação) */}
      {(punchToDelete || recordToDelete) && (
        <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-[200] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl w-full max-w-sm p-10 text-center animate-slide-up border dark:border-white/5">
            <div className="w-20 h-20 bg-rose-100 dark:bg-rose-900/30 rounded-full flex items-center justify-center mx-auto mb-6 text-rose-600">
              <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
            </div>
            <h3 className="text-lg font-black text-slate-900 dark:text-white uppercase italic mb-2 tracking-tight">Confirmar Lixo</h3>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mb-8">Tem a certeza que deseja eliminar este registo permanentemente?</p>
            <div className="flex gap-4">
              <button onClick={() => { setPunchToDelete(null); setRecordToDelete(null); }} className="flex-1 py-4 text-[10px] font-black uppercase text-slate-400">Cancelar</button>
              <button 
                onClick={() => {
                  if (punchToDelete) onDeletePunch(punchToDelete);
                  if (recordToDelete) onDeleteRecord(recordToDelete);
                  setPunchToDelete(null);
                  setRecordToDelete(null);
                }} 
                className="flex-[2] bg-rose-600 text-white py-4 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg"
              >
                Sim, Eliminar
              </button>
            </div>
          </div>
        </div>
      )}

      {showClearAllModal && (
        <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-[200] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl w-full max-w-sm p-10 text-center animate-slide-up border dark:border-white/5">
            <div className="w-20 h-20 bg-rose-100 dark:bg-rose-900/30 rounded-full flex items-center justify-center mx-auto mb-6 text-rose-600">
              <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
            </div>
            <h3 className="text-lg font-black text-slate-900 dark:text-white uppercase italic mb-2 tracking-tight">Limpeza de {activeTab === 'PUNCHES' ? 'Pontos' : 'Férias/Faltas'}</h3>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mb-8">Deseja apagar TODO o histórico visualizado nesta aba? Esta ação é irreversível.</p>
            <div className="flex gap-4">
              <button onClick={() => setShowClearAllModal(false)} className="flex-1 py-4 text-[10px] font-black uppercase text-slate-400">Cancelar</button>
              <button 
                onClick={() => {
                  if (activeTab === 'PUNCHES') onDeleteAllPunches();
                  else onDeleteAllRecords();
                  setShowClearAllModal(false);
                }} 
                className="flex-[2] bg-rose-600 text-white py-4 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg"
              >
                Eliminar Tudo
              </button>
            </div>
          </div>
        </div>
      )}

      {(isAddModalOpen || isEditModalOpen) && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[200] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl max-w-md w-full p-10 border dark:border-white/5">
            <h3 className="text-xl font-black uppercase mb-8 text-slate-900 dark:text-white italic tracking-tight">{isEditModalOpen ? 'Editar Registo' : 'Novo Ponto Manual'}</h3>
            <form onSubmit={isEditModalOpen ? handleEditSubmit : handleAddSubmit} className="space-y-5">
              {!isEditModalOpen && (
                <div>
                  <label className="text-[9px] font-black text-slate-400 uppercase block mb-1">Colaborador</label>
                  <select name="employeeId" required className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs font-bold dark:text-white outline-none">
                    {employees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                  </select>
                </div>
              )}
              <div className="grid grid-cols-2 gap-4">
                <input type="date" name="date" required defaultValue={isEditModalOpen ? new Date(editPunchData!.timestamp).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs font-bold dark:text-white outline-none" />
                <input type="time" name="time" required defaultValue={isEditModalOpen ? new Date(editPunchData!.timestamp).toLocaleTimeString('pt-PT', {hour:'2-digit', minute:'2-digit'}) : new Date().toLocaleTimeString('pt-PT', {hour:'2-digit', minute:'2-digit'})} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs font-bold dark:text-white outline-none" />
              </div>
              <select name="type" defaultValue={isEditModalOpen ? editPunchData!.type : PunchType.IN} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs font-bold dark:text-white outline-none">
                <option value={PunchType.IN}>Entrada</option>
                <option value={PunchType.OUT}>Saída</option>
              </select>
              <textarea name="notes" placeholder="Observações..." defaultValue={isEditModalOpen ? editPunchData!.notes : ''} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs font-bold dark:text-white h-24 resize-none outline-none" />
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => { setIsAddModalOpen(false); setIsEditModalOpen(false); }} className="flex-1 py-4 text-[10px] font-black uppercase text-slate-400">Cancelar</button>
                <button type="submit" className="flex-[2] bg-indigo-600 text-white py-4 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg">Confirmar</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isEditRecordModalOpen && editRecordData && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[200] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl max-w-md w-full p-10 border dark:border-white/5">
            <h3 className="text-xl font-black uppercase mb-8 text-slate-900 dark:text-white italic tracking-tight">Editar Férias/Falta</h3>
            <form onSubmit={handleEditRecordSubmit} className="space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <input type="date" name="date" required defaultValue={editRecordData.date} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs font-bold dark:text-white outline-none" />
                <input type="date" name="endDate" defaultValue={editRecordData.endDate} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs font-bold dark:text-white outline-none" />
              </div>
              <select name="type" defaultValue={editRecordData.type} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs font-bold dark:text-white outline-none">
                <option value="VACATION">Férias</option>
                <option value="ABSENCE">Falta</option>
              </select>
              <textarea name="reason" placeholder="Motivo..." defaultValue={editRecordData.reason} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs font-bold h-32 dark:text-white outline-none resize-none focus:border-indigo-600 transition-all shadow-inner" />
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setIsEditRecordModalOpen(false)} className="flex-1 py-4 text-[10px] font-black uppercase text-slate-400">Voltar</button>
                <button type="submit" className="flex-[2] bg-indigo-600 text-white py-4 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg">Guardar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default HistoryView;