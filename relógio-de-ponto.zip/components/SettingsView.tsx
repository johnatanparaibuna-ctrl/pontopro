import React, { useState, useRef, useMemo } from 'react';
import { EmailConfig, Employee, Punch, LocationConfig, AbsenceRecord, PunchType, EmployeeStatus } from '../types';
import { StorageService } from '../services/storage';

interface SettingsViewProps {
  emailConfig: EmailConfig;
  onSaveEmailConfig: (config: EmailConfig) => void;
  onImportData: (data: { employees: Employee[], punches: Punch[], records: AbsenceRecord[] }) => void;
  employees: Employee[];
  punches: Punch[];
  records: AbsenceRecord[];
}

type ReportType = 'DAY' | 'WEEK' | 'MONTH' | 'YEAR';

const SettingsView: React.FC<SettingsViewProps> = ({ emailConfig, onSaveEmailConfig, onImportData, employees, punches, records }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [localEmailConfig, setLocalEmailConfig] = useState<EmailConfig>(emailConfig);
  const [localLocationConfig, setLocalLocationConfig] = useState<LocationConfig>(StorageService.getLocationConfig());
  
  // Filtros de Relatório
  const [reportType, setReportType] = useState<ReportType>('MONTH');
  const [reportDate, setReportDate] = useState(new Date().toISOString().split('T')[0]);
  const [reportMonth, setReportMonth] = useState(new Date().toISOString().slice(0, 7));
  const [reportYear, setReportYear] = useState(new Date().getFullYear().toString());

  const [isSaved, setIsSaved] = useState(false);
  const [isCapturing, setIsCapturing] = useState(false);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput === '2303') {
      setIsAuthenticated(true);
      setPinInput('');
    } else {
      alert('PIN Incorreto!');
      setPinInput('');
    }
  };

  const handleSave = () => {
    onSaveEmailConfig(localEmailConfig);
    StorageService.saveLocationConfig(localLocationConfig);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const formatH = (h: number) => {
    const totalMinutes = Math.round(h * 60);
    const hours = Math.floor(Math.abs(totalMinutes) / 60);
    const minutes = Math.abs(totalMinutes) % 60;
    const sign = h < 0 ? '-' : '';
    return `${sign}${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  };

  const reportRange = useMemo(() => {
    let start = '';
    let end = '';
    const d = new Date(reportDate);

    if (reportType === 'DAY') {
      start = reportDate;
      end = reportDate;
    } else if (reportType === 'WEEK') {
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      const monday = new Date(d.setDate(diff));
      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);
      start = monday.toISOString().split('T')[0];
      end = sunday.toISOString().split('T')[0];
    } else if (reportType === 'MONTH') {
      const [y, m] = reportMonth.split('-').map(Number);
      start = `${y}-${m.toString().padStart(2, '0')}-01`;
      end = new Date(y, m, 0).toISOString().split('T')[0];
    } else if (reportType === 'YEAR') {
      start = `${reportYear}-01-01`;
      end = `${reportYear}-12-31`;
    }

    return { start, end };
  }, [reportType, reportDate, reportMonth, reportYear]);

  const summaryData = useMemo(() => {
    const { start, end } = reportRange;
    if (!start || !end) return [];

    const startDate = new Date(start);
    const endDate = new Date(end);
    
    return employees.map(emp => {
      let totalWorked = 0;
      let totalTarget = 0;
      let current = new Date(startDate);

      while (current <= endDate) {
        const dateStr = current.toISOString().split('T')[0];
        const dayPunches = punches.filter(p => p.employeeId === emp.id && p.timestamp.startsWith(dateStr))
          .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
        
        const firstIn = dayPunches.find(p => p.type === PunchType.IN);
        const lastOut = [...dayPunches].reverse().find(p => p.type === PunchType.OUT);
        
        const isVacation = records.some(r => r.employeeId === emp.id && r.type === 'VACATION' && dateStr >= r.date && (!r.endDate || dateStr <= r.endDate));
        const dayOfWeek = current.getDay();
        const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

        if (!isWeekend && !isVacation) {
          totalTarget += (emp.dailyWorkHours || 8);
        }

        if (firstIn && lastOut) {
          const diffMs = new Date(lastOut.timestamp).getTime() - new Date(firstIn.timestamp).getTime();
          totalWorked += (diffMs / (1000 * 60 * 60));
        }
        current.setDate(current.getDate() + 1);
      }

      return {
        id: emp.id,
        name: emp.name,
        worked: totalWorked,
        target: totalTarget,
        balance: totalWorked - totalTarget
      };
    });
  }, [reportRange, employees, punches, records]);

  const exportReport = () => {
    const { start, end } = reportRange;
    const BOM = '\uFEFF';
    let csvContent = "Data;Colaborador;Estado;Entrada;Saida;H. Reais;Saldo;Observacoes\n";
    
    let current = new Date(start);
    const endDate = new Date(end);

    while (current <= endDate) {
      const dateStr = current.toISOString().split('T')[0];
      employees.forEach(emp => {
        const dayPunches = punches.filter(p => p.employeeId === emp.id && p.timestamp.startsWith(dateStr))
          .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
        
        const firstIn = dayPunches.find(p => p.type === PunchType.IN);
        const lastOut = [...dayPunches].reverse().find(p => p.type === PunchType.OUT);
        const allNotes = dayPunches.map(p => p.notes).filter(Boolean).join(' | ').replace(/;/g, ',');

        const isVacation = records.some(r => r.employeeId === emp.id && r.type === 'VACATION' && dateStr >= r.date && (!r.endDate || dateStr <= r.endDate));
        const status = isVacation ? "Férias" : dayPunches.length > 0 ? "Presente" : "Falta/Descanso";

        const worked = firstIn && lastOut ? (new Date(lastOut.timestamp).getTime() - new Date(firstIn.timestamp).getTime()) / (1000*60*60) : 0;
        const target = (current.getDay() === 0 || current.getDay() === 6 || isVacation) ? 0 : (emp.dailyWorkHours || 8);

        csvContent += `${dateStr};${emp.name};${status};${firstIn ? new Date(firstIn.timestamp).toLocaleTimeString() : '---'};${lastOut ? new Date(lastOut.timestamp).toLocaleTimeString() : '---'};${formatH(worked)};${formatH(worked - target)};${allNotes}\n`;
      });
      current.setDate(current.getDate() + 1);
    }

    const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Relatorio_${reportType}_${start}_a_${end}.csv`;
    link.click();
  };

  const captureLocation = () => {
    setIsCapturing(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocalLocationConfig({ ...localLocationConfig, lat: pos.coords.latitude, lng: pos.coords.longitude });
        setIsCapturing(false);
      },
      () => { alert('Erro GPS'); setIsCapturing(false); }
    );
  };

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] px-4 animate-fade-in">
        <form onSubmit={handleAuth} className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-2xl border border-slate-100 dark:border-slate-800 text-center space-y-6 w-full max-w-sm">
          <div className="w-16 h-16 bg-indigo-600 rounded-2xl mx-auto flex items-center justify-center text-white mb-2 shadow-lg">
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
          </div>
          <h2 className="text-xl font-black uppercase text-slate-800 dark:text-white">Admin Access</h2>
          <input 
            type="password" 
            value={pinInput} 
            onChange={e => setPinInput(e.target.value.replace(/\D/g, '').slice(0, 4))} 
            placeholder="••••" 
            className="w-full bg-slate-50 dark:bg-slate-800 p-5 rounded-2xl text-center text-4xl font-mono outline-none border-2 border-transparent focus:border-indigo-600 dark:text-white transition-all shadow-inner" 
            autoFocus 
          />
          <button type="submit" className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-black text-xs uppercase shadow-xl hover:opacity-90 transition-all">Desbloquear</button>
        </form>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in pb-20">
      <header>
        <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100 uppercase tracking-tight">Gestão de Relatórios</h2>
        <p className="text-slate-500 dark:text-slate-400 text-sm italic">Filtros de Exportação por Período</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-6 md:col-span-2">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="flex items-center gap-3 text-indigo-600">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z" /></svg>
              <h3 className="font-black uppercase text-xs tracking-widest">Painel de Exportação</h3>
            </div>
            <button onClick={exportReport} className="bg-emerald-600 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase shadow-lg hover:bg-emerald-500 transition-all flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1M12 12h.01M16 12h.01M8 12h.01M12 16h.01M12 8h.01M12 4v4m0 0l-3-3m3 3l3-3" /></svg>
              Gerar Relatório CSV
            </button>
          </div>
          
          <div className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-2xl space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase block mb-1">Filtrar por</label>
                <select value={reportType} onChange={e => setReportType(e.target.value as ReportType)} className="w-full px-4 py-3 bg-white dark:bg-slate-900 border-none rounded-xl outline-none text-xs font-bold shadow-sm">
                  <option value="DAY">Diário</option>
                  <option value="WEEK">Semanal</option>
                  <option value="MONTH">Mensal</option>
                  <option value="YEAR">Anual</option>
                </select>
              </div>

              {reportType === 'DAY' || reportType === 'WEEK' ? (
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase block mb-1">Escolher Data</label>
                  <input type="date" value={reportDate} onChange={e => setReportDate(e.target.value)} className="w-full px-4 py-3 bg-white dark:bg-slate-900 border-none rounded-xl text-xs font-bold shadow-sm" />
                </div>
              ) : reportType === 'MONTH' ? (
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase block mb-1">Mês/Ano</label>
                  <input type="month" value={reportMonth} onChange={e => setReportMonth(e.target.value)} className="w-full px-4 py-3 bg-white dark:bg-slate-900 border-none rounded-xl text-xs font-bold shadow-sm" />
                </div>
              ) : (
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase block mb-1">Ano</label>
                  <input type="number" value={reportYear} min="2020" max="2100" onChange={e => setReportYear(e.target.value)} className="w-full px-4 py-3 bg-white dark:bg-slate-900 border-none rounded-xl text-xs font-bold shadow-sm" />
                </div>
              )}
            </div>

            <div className="overflow-x-auto border-none rounded-2xl shadow-inner bg-white dark:bg-slate-900">
              <table className="w-full text-left">
                <thead className="text-[9px] font-black uppercase text-slate-400 bg-slate-50 dark:bg-slate-800">
                  <tr>
                    <th className="p-4">Colaborador</th>
                    <th className="p-4 text-center">H. Reais</th>
                    <th className="p-4 text-center">H. Definidas</th>
                    <th className="p-4 text-right">Saldo Final</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {summaryData.map(item => (
                    <tr key={item.id} className="text-xs font-bold hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="p-4 uppercase text-slate-700 dark:text-slate-300">{item.name}</td>
                      <td className="p-4 text-center font-mono">{formatH(item.worked)}</td>
                      <td className="p-4 text-center font-mono text-slate-400">{formatH(item.target)}</td>
                      <td className={`p-4 text-right font-mono ${item.balance >= 0 ? 'text-green-600' : 'text-rose-600'}`}>
                        {item.balance > 0 ? '+' : ''}{formatH(item.balance)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-6">
          <h3 className="font-black uppercase text-xs text-indigo-600 tracking-widest">Configuração GPS</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-[10px] font-black text-slate-400 uppercase">Geo-Fencing Obrigatório</label>
              <button onClick={() => setLocalLocationConfig({...localLocationConfig, enabled: !localLocationConfig.enabled})} className={`w-12 h-6 rounded-full transition-colors relative ${localLocationConfig.enabled ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'}`}>
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${localLocationConfig.enabled ? 'left-7' : 'left-1'}`} />
              </button>
            </div>
            <button onClick={captureLocation} disabled={isCapturing} className="w-full bg-slate-50 dark:bg-slate-800 text-indigo-600 font-black py-4 rounded-xl text-[9px] uppercase hover:bg-indigo-100 transition-colors border border-indigo-50 shadow-sm">
              {isCapturing ? 'A obter GPS...' : 'Marcar Coordenadas da Sede'}
            </button>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-6 flex flex-col justify-center">
           <button onClick={handleSave} className="w-full bg-indigo-600 text-white font-black py-5 rounded-2xl text-xs uppercase tracking-widest shadow-xl hover:bg-indigo-700 transition-all active:scale-95">
            {isSaved ? 'Configurações Guardadas!' : 'Guardar Alterações'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsView;