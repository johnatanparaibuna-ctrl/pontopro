import React from 'react';
import { Employee, Punch, AbsenceRecord, EmployeeStatus, PunchType } from '../types';

interface DashboardProps {
  employees: Employee[];
  punches: Punch[];
  records: AbsenceRecord[];
  theme: 'light' | 'dark';
}

const Dashboard: React.FC<DashboardProps> = ({ employees, punches }) => {
  const now = new Date();
  const dayOfWeek = now.getDay();
  const isWeekend = dayOfWeek === 0 || dayOfWeek === 6; // 0 = Domingo, 6 = Sábado
  const today = now.toISOString().split('T')[0];
  const todayPunches = punches.filter(p => p.timestamp.startsWith(today));
  
  const presentCount = Array.from(new Set(todayPunches.filter(p => p.type === PunchType.IN).map(p => p.employeeId))).length;
  const vacationCount = employees.filter(e => e.status === EmployeeStatus.VACATION).length;
  const absentCount = employees.filter(e => e.status === EmployeeStatus.ABSENT).length;

  return (
    <div className="space-y-10 animate-fade-in pb-16">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h2 className="text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-none mb-2 italic uppercase">Painel Principal</h2>
          <p className="text-slate-500 font-bold uppercase tracking-[0.2em] text-[10px] flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-ping"></span>
            {new Date().toLocaleDateString('pt-PT', { weekday:'long', day:'numeric', month:'long' })}
          </p>
        </div>
        
        <div className="flex items-center gap-4 px-6 py-4 glass rounded-[1.5rem] border dark:border-white/5">
          <div className="flex flex-col items-end">
             <span className="text-[11px] font-extrabold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">Sincronização Ativa</span>
             <span className="text-[9px] font-bold text-slate-400 uppercase tracking-tight">Base de Dados OK</span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-indigo-600/10 flex items-center justify-center text-indigo-600">
             <svg className="w-6 h-6 animate-spin-slow" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Total Colaboradores', value: employees.length, color: 'indigo', icon: '👥' },
          { label: 'Presentes Agora', value: isWeekend ? 0 : presentCount, color: 'emerald', icon: '⚡' },
          { label: 'Em Férias', value: vacationCount, color: 'amber', icon: '🌴' },
          { label: 'Faltas Hoje', value: absentCount, color: 'rose', icon: '⚠️' },
        ].map((s, i) => (
          <div key={i} className="group relative bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-100 dark:border-white/5 shadow-xl shadow-slate-200/50 dark:shadow-none hover:-translate-y-2 transition-all duration-300">
            <div className={`absolute top-0 right-0 w-24 h-24 -mr-8 -mt-8 rounded-full blur-2xl opacity-10 bg-${s.color}-500 group-hover:opacity-20 transition-opacity`}></div>
            <div className="text-3xl mb-4">{s.icon}</div>
            <div className="text-5xl font-black dark:text-white tracking-tighter mb-1">{s.value}</div>
            <div className="text-[10px] font-black uppercase text-slate-400 tracking-[0.15em] leading-none">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-10">
        <div className="xl:col-span-2 bg-white dark:bg-slate-900 rounded-[3rem] border border-slate-100 dark:border-white/5 overflow-hidden shadow-2xl">
          <div className="p-10 border-b border-slate-50 dark:border-slate-800 flex justify-between items-center bg-slate-50/30 dark:bg-slate-900/50">
            <h3 className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-widest">Resumo de Atividade</h3>
            <div className="flex gap-2 text-[10px] font-black uppercase text-slate-400 tracking-widest">
              {isWeekend ? "Descanso Semanal" : "Dia de Trabalho"}
            </div>
          </div>
          <div className="overflow-x-auto custom-scrollbar">
            {isWeekend ? (
              <div className="p-20 flex flex-col items-center justify-center text-center opacity-40">
                <div className="w-20 h-20 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center text-3xl mb-4 shadow-inner">🏠</div>
                <p className="text-sm font-black uppercase tracking-widest text-slate-600 dark:text-slate-400 italic">Fim de Semana</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mt-2">Os registos estão suspensos durante o descanso semanal.</p>
              </div>
            ) : (
              <table className="w-full text-left">
                <thead className="bg-slate-50 dark:bg-slate-800/30 text-[10px] font-black uppercase text-slate-400 tracking-widest">
                  <tr>
                    <th className="px-10 py-6">Colaborador</th>
                    <th className="px-10 py-6 text-center">Entrada</th>
                    <th className="px-10 py-6 text-center">Saída</th>
                    <th className="px-10 py-6">Estado / Obs.</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {employees.map(emp => {
                    const dayPunches = todayPunches.filter(p => p.employeeId === emp.id)
                      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
                    const firstIn = dayPunches.find(p => p.type === PunchType.IN);
                    const lastOut = [...dayPunches].reverse().find(p => p.type === PunchType.OUT);
                    
                    const isVacation = emp.status === EmployeeStatus.VACATION;
                    const isAbsent = emp.status === EmployeeStatus.ABSENT;

                    return (
                      <tr key={emp.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/20 transition-colors">
                        <td className="px-10 py-6">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black shadow-inner overflow-hidden border border-slate-200 dark:border-slate-700">
                              {emp.avatar ? <img src={emp.avatar} className="w-full h-full object-cover" /> : <span className="text-slate-400 text-xs">{emp.name[0]}</span>}
                            </div>
                            <div>
                              <p className="font-bold text-sm text-slate-800 dark:text-white uppercase tracking-tight">{emp.name}</p>
                              <p className="text-[9px] text-indigo-500 font-extrabold uppercase tracking-widest">{emp.role}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-10 py-6 text-center">
                          <div className="flex flex-col items-center">
                            <span className={`font-mono text-xs font-black ${firstIn ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-200 dark:text-slate-800'}`}>
                              {firstIn ? new Date(firstIn.timestamp).toLocaleTimeString('pt-PT', {hour:'2-digit', minute:'2-digit'}) : '--:--'}
                            </span>
                            {firstIn?.location && (
                              <span className="text-[7px] text-slate-400 dark:text-slate-500 font-bold flex items-center gap-0.5 mt-0.5 whitespace-nowrap">
                                <svg className="w-2 h-2" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" /></svg>
                                Lat: {firstIn.location.lat.toFixed(3)}, Lng: {firstIn.location.lng.toFixed(3)}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-10 py-6 text-center">
                          <div className="flex flex-col items-center">
                            <span className={`font-mono text-xs font-black ${lastOut ? 'text-rose-600 dark:text-rose-400' : 'text-slate-200 dark:text-slate-800'}`}>
                              {lastOut ? new Date(lastOut.timestamp).toLocaleTimeString('pt-PT', {hour:'2-digit', minute:'2-digit'}) : '--:--'}
                            </span>
                            {lastOut?.location && (
                              <span className="text-[7px] text-slate-400 dark:text-slate-500 font-bold flex items-center gap-0.5 mt-0.5 whitespace-nowrap">
                                <svg className="w-2 h-2" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" /></svg>
                                Lat: {lastOut.location.lat.toFixed(3)}, Lng: {lastOut.location.lng.toFixed(3)}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-10 py-6">
                           {isVacation ? (
                              <span className="bg-amber-100 text-amber-700 px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest border border-amber-200">🌴 Férias</span>
                           ) : isAbsent ? (
                              <span className="bg-rose-100 text-rose-700 px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest border border-rose-200">⚠️ Falta</span>
                           ) : dayPunches.length === 0 ? (
                              <div className="flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
                                <span className="text-[9px] text-rose-600 dark:text-rose-400 font-black uppercase tracking-[0.1em] italic">SEM REGISTO</span>
                              </div>
                           ) : (
                              <span className="text-[9px] text-emerald-600 font-black uppercase tracking-widest flex items-center gap-1">
                                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
                                Presente
                              </span>
                           )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-[3rem] border border-slate-100 dark:border-white/5 p-10 shadow-2xl">
          <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] mb-8 border-b border-slate-50 dark:border-slate-800 pb-4">Férias e Faltas</h3>
          <div className="space-y-6">
            {employees.filter(e => e.status !== EmployeeStatus.ACTIVE).length === 0 ? (
              <div className="py-20 flex flex-col items-center justify-center opacity-30 text-center">
                <p className="text-[10px] font-black uppercase italic tracking-widest text-slate-400">Toda a equipa disponível</p>
              </div>
            ) : (
              employees.filter(e => e.status !== EmployeeStatus.ACTIVE).map(emp => (
                <div key={emp.id} className="flex items-center gap-5 p-5 bg-slate-50 dark:bg-slate-800/40 rounded-[2rem] border border-slate-100 dark:border-slate-700">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-lg ${emp.status === EmployeeStatus.VACATION ? 'bg-amber-100' : 'bg-rose-100'}`}>
                    {emp.status === EmployeeStatus.VACATION ? '🌴' : '⚠️'}
                  </div>
                  <div>
                    <p className="text-sm font-black text-slate-800 dark:text-white uppercase leading-tight">{emp.name}</p>
                    <p className={`text-[10px] font-extrabold uppercase tracking-widest ${emp.status === EmployeeStatus.VACATION ? 'text-amber-600' : 'text-rose-600'}`}>
                      {emp.status === EmployeeStatus.VACATION ? 'Férias Ativas' : 'Falta Registada'}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;