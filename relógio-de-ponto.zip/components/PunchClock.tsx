import React, { useState, useRef, useEffect } from 'react';
import { PunchType, EntryModality, Employee, LocationConfig, Punch } from '../types';

interface PunchClockProps {
  employees: Employee[];
  punches: Punch[];
  locationConfig: LocationConfig;
  onPunch: (code: string, options?: { 
    manualData?: { type: PunchType; timestamp: string }, 
    modality?: EntryModality,
    location?: { lat: number, lng: number },
    forceType?: PunchType,
    notes?: string
  }) => { success: boolean; message: string; employeeName?: string; type?: string };
}

const PunchClock: React.FC<PunchClockProps> = ({ onPunch, locationConfig, employees, punches }) => {
  const [mode, setMode] = useState<'AUTO' | 'MANUAL'>('AUTO');
  const [code, setCode] = useState('');
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState<{ type: 'success' | 'error' | 'info' | null; message: string; hasGPS?: boolean }>({ type: null, message: '' });
  const [isProcessing, setIsProcessing] = useState(false);
  const [identifiedEmployee, setIdentifiedEmployee] = useState<Employee | null>(null);
  
  const manualDate = new Date().toISOString().split('T')[0];
  const manualTime = new Date().toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' });

  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, [mode]);

  useEffect(() => {
    if (code.length === 4) {
      const emp = employees.find(e => e.code === code);
      setIdentifiedEmployee(emp || null);
    } else {
      setIdentifiedEmployee(null);
    }
  }, [code, employees]);

  const executePunch = (locationData?: { lat: number, lng: number }) => {
    let result;
    const finalLocation = locationData || (locationConfig.lat && locationConfig.lng ? { lat: locationConfig.lat, lng: locationConfig.lng } : undefined);

    if (mode === 'AUTO') {
      const type = getNextAutoType();
      result = onPunch(code, { modality: EntryModality.PIN, location: finalLocation, forceType: type, notes });
    } else {
      const timestamp = new Date(`${manualDate}T${manualTime}:00`).toISOString();
      result = onPunch(code, { 
        manualData: { type: PunchType.IN, timestamp }, 
        modality: EntryModality.PIN,
        location: finalLocation,
        notes
      });
    }

    if (result.success) {
      setStatus({ type: 'success', message: result.message, hasGPS: !!finalLocation });
      setCode('');
      setNotes('');
      setIdentifiedEmployee(null);
    } else {
      setStatus({ type: 'error', message: result.message });
    }
    
    setIsProcessing(false);
    setTimeout(() => setStatus({ type: null, message: '' }), 8000);
    inputRef.current?.focus();
  };

  const getNextAutoType = () => {
    if (!identifiedEmployee) return PunchType.IN;
    const today = new Date().toISOString().split('T')[0];
    const todayPunches = punches.filter(p => p.employeeId === identifiedEmployee.id && p.timestamp.startsWith(today));
    return todayPunches.length % 2 === 0 ? PunchType.IN : PunchType.OUT;
  };

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (code.length < 4) return;
    setIsProcessing(true);
    
    if (!navigator.geolocation) {
      executePunch();
      return;
    }

    setStatus({ type: 'info', message: 'A obter localização GPS...' });
    navigator.geolocation.getCurrentPosition(
      (position) => executePunch({ lat: position.coords.latitude, lng: position.coords.longitude }),
      () => executePunch(),
      { enableHighAccuracy: true, timeout: 5000 }
    );
  };

  const autoType = identifiedEmployee ? getNextAutoType() : null;

  return (
    <div className="max-w-md mx-auto py-6 px-4 animate-slide-up transition-all duration-500">
      {/* Seletor de Modo Uniforme */}
      <div className="flex bg-slate-200/50 dark:bg-slate-900/50 p-1.5 rounded-2xl glass mb-6">
        <button onClick={() => { setMode('AUTO'); setCode(''); }} className={`flex-1 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${mode === 'AUTO' ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-white shadow-md' : 'text-slate-500'}`}>Automático</button>
        <button onClick={() => { setMode('MANUAL'); setCode(''); }} className={`flex-1 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${mode === 'MANUAL' ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-white shadow-md' : 'text-slate-500'}`}>Manual</button>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl border border-slate-100 dark:border-white/5 overflow-hidden min-h-[560px] flex flex-col">
        {/* Secção de Perfil (Altura Reduzida) */}
        <div className="bg-slate-950 p-6 text-center relative flex flex-col items-center justify-center h-48">
          <div className="absolute top-0 left-0 w-full h-1 bg-indigo-600"></div>
          
          {identifiedEmployee ? (
            <div className="animate-in zoom-in duration-300 flex flex-col items-center">
              <div className="w-16 h-16 rounded-2xl border-2 border-indigo-500/40 p-0.5 bg-slate-900 relative shadow-lg">
                <div className="w-full h-full rounded-[0.8rem] bg-indigo-600/10 flex items-center justify-center overflow-hidden">
                  {identifiedEmployee.avatar ? (
                    <img src={identifiedEmployee.avatar} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-2xl font-black text-indigo-500">{identifiedEmployee.name[0]}</span>
                  )}
                </div>
                <div className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full border-2 border-slate-950 flex items-center justify-center text-white shadow-md ${autoType === PunchType.IN ? 'bg-emerald-600' : 'bg-rose-600'}`}>
                   <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d={autoType === PunchType.IN ? "M5 13l4 4L19 7" : "M17 16l4-4m0 0l-4-4m4 4H7"} /></svg>
                </div>
              </div>
              <p className="text-white text-sm font-black uppercase tracking-wider mt-3">{identifiedEmployee.name}</p>
              <p className="text-indigo-400 text-[8px] font-black uppercase tracking-[0.3em] mt-1 italic">Validado</p>
            </div>
          ) : (
            <div className="opacity-20 flex flex-col items-center">
              <svg className="w-12 h-12 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A10.003 10.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>
              <p className="text-white text-[8px] font-black uppercase tracking-[0.4em] mt-2">Pronto a Identificar</p>
            </div>
          )}
        </div>

        {/* Formulário Uniforme */}
        <div className="p-8 space-y-5 flex-1 flex flex-col justify-center">
          <div className="space-y-1">
            <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-4">Código PIN</label>
            <input
              ref={inputRef}
              type="password"
              inputMode="numeric"
              pattern="[0-9]*"
              value={code}
              onChange={e => setCode(e.target.value.replace(/\D/g, '').slice(0, 4))}
              placeholder="••••"
              className="w-full bg-slate-50 dark:bg-slate-950 border-2 border-slate-100 dark:border-slate-800 rounded-2xl px-4 py-5 text-4xl text-center dark:text-white font-mono tracking-[0.6em] focus:outline-none focus:border-indigo-600 transition-all placeholder:text-slate-200 dark:placeholder:text-slate-800"
              autoComplete="off"
            />
          </div>
          
          <div className="space-y-1">
            <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-4">Notas do Turno</label>
            <textarea 
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Ex: Entrega de documentos..."
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-2xl px-5 py-4 dark:text-white text-xs font-medium placeholder:text-slate-300 dark:placeholder:text-slate-800 resize-none h-20"
            />
          </div>

          <button
            onClick={() => handleSubmit()}
            disabled={code.length < 4 || isProcessing}
            className={`w-full py-5 rounded-2xl text-white font-black text-[11px] uppercase tracking-[0.3em] transition-all shadow-xl ${
              code.length < 4 || isProcessing 
                ? 'bg-slate-100 dark:bg-slate-800 text-slate-300 cursor-not-allowed' 
                : autoType === PunchType.OUT ? 'bg-rose-600 shadow-rose-600/30' : 'bg-indigo-600 shadow-indigo-600/30'
            }`}
          >
            {isProcessing ? 'A validar...' : autoType === PunchType.OUT ? 'Registar Saída' : 'Registar Entrada'}
          </button>
        </div>

        {/* Área de Feedback Fixa */}
        <div className="p-6 bg-slate-50/50 dark:bg-slate-950/20 border-t border-slate-100 dark:border-white/5 h-24 flex items-center justify-center">
          {status.type ? (
            <div className={`w-full px-4 py-3 rounded-xl border flex items-center justify-between gap-3 animate-in fade-in slide-in-from-bottom-2 ${
              status.type === 'success' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 
              status.type === 'info' ? 'bg-indigo-50 text-indigo-700 border-indigo-100' :
              'bg-rose-50 text-rose-700 border-rose-100'
            }`}>
               <span className="text-[10px] font-black uppercase leading-tight truncate">{status.message}</span>
               {status.hasGPS && <span className="bg-emerald-600 text-white text-[7px] font-black px-2 py-0.5 rounded uppercase">GPS OK</span>}
            </div>
          ) : (
            <div className="flex gap-1.5 opacity-20">
               {[...Array(4)].map((_, i) => <div key={i} className="w-1.5 h-1.5 rounded-full bg-slate-400"></div>)}
            </div>
          )}
        </div>
      </div>
      <p className="text-center mt-6 text-slate-400 text-[8px] font-black uppercase tracking-[0.4em] opacity-50">Enterprise Ponto v3.4 • PT-PT</p>
    </div>
  );
};

export default PunchClock;