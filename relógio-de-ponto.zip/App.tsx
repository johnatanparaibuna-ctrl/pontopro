import React, { useState, useEffect } from 'react';
import { AppView, Employee, Punch, AbsenceRecord, EmployeeStatus, PunchType, EntryMethod, EntryModality, EmailConfig, LocationConfig } from './types';
import { StorageService } from './services/storage';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import PunchClock from './components/PunchClock';
import EmployeeManager from './components/EmployeeManager';
import HistoryView from './components/HistoryView';
import SettingsView from './components/SettingsView';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('DASHBOARD');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [punches, setPunches] = useState<Punch[]>([]);
  const [records, setRecords] = useState<AbsenceRecord[]>([]);
  const [emailConfig, setEmailConfig] = useState<EmailConfig>(StorageService.getEmailConfig());
  const [locationConfig, setLocationConfig] = useState<LocationConfig>(StorageService.getLocationConfig());
  const [theme, setTheme] = useState<'light' | 'dark'>(StorageService.getTheme());

  useEffect(() => {
    setEmployees(StorageService.getEmployees());
    setPunches(StorageService.getPunches());
    setRecords(StorageService.getRecords());
  }, []);

  useEffect(() => {
    if (theme === 'dark') document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
    StorageService.saveTheme(theme);
  }, [theme]);

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  const handlePunch = (code: string, options?: { 
    manualData?: { type: PunchType; timestamp: string, method?: EntryMethod }, 
    modality?: EntryModality,
    location?: { lat: number, lng: number },
    forceType?: PunchType,
    notes?: string
  }) => {
    const employee = employees.find(e => e.code === code);
    if (!employee) return { success: false, message: 'Identificação incorreta!' };
    
    if (employee.status === EmployeeStatus.VACATION) {
      return { success: false, message: `ACESSO NEGADO: ${employee.name} está em FÉRIAS.` };
    }

    const { manualData, modality = EntryModality.PIN, location, forceType, notes } = options || {};
    const method = manualData?.method || (manualData ? EntryMethod.MANUAL : EntryMethod.AUTO);
    const now = manualData ? new Date(manualData.timestamp) : new Date();
    const todayStr = now.toISOString().split('T')[0];

    const todayPunches = punches.filter(p => p.employeeId === employee.id && p.timestamp.startsWith(todayStr));
    const finalType = forceType || (manualData ? manualData.type : (todayPunches.length % 2 === 0 ? PunchType.IN : PunchType.OUT));

    const newPunch: Punch = {
      id: Math.random().toString(36).substr(2, 9),
      employeeId: employee.id,
      type: finalType,
      timestamp: now.toISOString(),
      entryMethod: method,
      modality: modality,
      location: location,
      notes: notes
    };

    setPunches(prev => {
      const updated = [...prev, newPunch];
      StorageService.savePunches(updated);
      return updated;
    });

    return { success: true, message: `${newPunch.type === 'IN' ? 'ENTRADA' : 'SAÍDA'} registada para ${employee.name}.` };
  };

  const handleUpdateStatus = (id: string, status: EmployeeStatus, vStart?: string, vEnd?: string, aDate?: string, aReason?: string) => {
    setEmployees(prev => {
      const updated = prev.map(e => {
        if (e.id !== id) return e;
        return { 
          ...e, 
          status, 
          vacationStart: status === EmployeeStatus.VACATION ? vStart : undefined, 
          vacationEnd: status === EmployeeStatus.VACATION ? vEnd : undefined,
          absenceDate: status === EmployeeStatus.ABSENT ? aDate : undefined,
          absenceReason: status === EmployeeStatus.ABSENT ? aReason : undefined
        };
      });
      StorageService.saveEmployees(updated);
      return updated;
    });

    if (status !== EmployeeStatus.ACTIVE) {
      const newRecord: AbsenceRecord = {
        id: Math.random().toString(36).substr(2, 9),
        employeeId: id,
        date: status === EmployeeStatus.VACATION ? (vStart || new Date().toISOString().split('T')[0]) : (aDate || new Date().toISOString().split('T')[0]),
        endDate: status === EmployeeStatus.VACATION ? vEnd : undefined,
        type: status === EmployeeStatus.VACATION ? 'VACATION' : 'ABSENCE',
        reason: status === EmployeeStatus.VACATION ? `Férias: ${vStart} a ${vEnd}` : aReason
      };
      setRecords(prev => {
        const updated = [...prev, newRecord];
        StorageService.saveRecords(updated);
        return updated;
      });
    }
  };

  const renderView = () => {
    switch (view) {
      case 'DASHBOARD': return <Dashboard employees={employees} punches={punches} records={records} theme={theme} />;
      case 'PUNCH': return <PunchClock employees={employees} punches={punches} onPunch={handlePunch} locationConfig={locationConfig} />;
      case 'EMPLOYEES': return <EmployeeManager 
        employees={employees} 
        records={records} 
        onAdd={(emp) => { 
          const n = {...emp, id: Math.random().toString(36).substr(2, 9)};
          setEmployees(prev => {
            const updated = [...prev, n];
            StorageService.saveEmployees(updated);
            return updated;
          });
        }} 
        onEdit={(up) => {
          setEmployees(prev => {
            const updated = prev.map(e => e.id === up.id ? up : e);
            StorageService.saveEmployees(updated);
            return updated;
          });
        }} 
        onDeleteAll={() => {
          setEmployees([]);
          setPunches([]);
          setRecords([]);
          StorageService.saveEmployees([]);
          StorageService.savePunches([]);
          StorageService.saveRecords([]);
        }} 
        onUpdateStatus={handleUpdateStatus} 
        onDelete={(id) => {
          setEmployees(prev => {
            const updated = prev.filter(e => e.id !== id);
            StorageService.saveEmployees(updated);
            return updated;
          });
          setPunches(prev => {
            const updated = prev.filter(p => p.employeeId !== id);
            StorageService.savePunches(updated);
            return updated;
          });
          setRecords(prev => {
            const updated = prev.filter(r => r.employeeId !== id);
            StorageService.saveRecords(updated);
            return updated;
          });
        }} 
      />;
      case 'HISTORY': return (
        <HistoryView 
          employees={employees} 
          punches={punches} 
          records={records} 
          locationConfig={locationConfig}
          onAddPunch={(p) => {
            setPunches(prev => {
              const updated = [...prev, p];
              StorageService.savePunches(updated);
              return updated;
            });
          }}
          onEditPunch={(p) => {
            setPunches(prev => {
              const updated = prev.map(old => old.id === p.id ? p : old);
              StorageService.savePunches(updated);
              return updated;
            });
          }}
          onDeletePunch={(id) => {
            setPunches(prev => {
              const updated = prev.filter(p => p.id !== id);
              StorageService.savePunches(updated);
              return updated;
            });
          }}
          onDeleteRecord={(id) => {
            setRecords(prev => {
              const updated = prev.filter(r => r.id !== id);
              StorageService.saveRecords(updated);
              return updated;
            });
          }}
          onEditRecord={(record) => {
            setRecords(prev => {
              const updated = prev.map(r => r.id === record.id ? record : r);
              StorageService.saveRecords(updated);
              return updated;
            });
          }}
          onIgnoreAbsence={() => {}} 
          onDeleteAllPunches={() => {
            setPunches([]);
            StorageService.savePunches([]);
          }} 
          onDeleteAllRecords={() => {
            setRecords([]);
            StorageService.saveRecords([]);
          }}
        />
      );
      case 'SETTINGS': return <SettingsView emailConfig={emailConfig} onSaveEmailConfig={StorageService.saveEmailConfig} onImportData={() => {}} employees={employees} punches={punches} records={records} />;
      default: return <Dashboard employees={employees} punches={punches} records={records} theme={theme} />;
    }
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      <Sidebar currentView={view} setView={setView} theme={theme} toggleTheme={toggleTheme} />
      <main className="flex-1 overflow-y-auto bg-slate-50 dark:bg-slate-950 p-4 md:p-8">
        <div className="max-w-6xl mx-auto">{renderView()}</div>
      </main>
    </div>
  );
};

export default App;